package com.cognizant.loanmanagement.repositories;

public class UserRepositoryTest {

}
