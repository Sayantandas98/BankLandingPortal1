package com.cognizant.loanmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.loanapplication.BankLandingPortal1Application;

@SpringBootTest(classes = BankLandingPortal1Application.class)
class BankLandingPortal1ApplicationTests {


}
