package com.cognizant.loanapplication.dtos;

import java.util.Objects;

import lombok.Data;

@Data
public class UserRequest {
	
	private String userName;
	private String password;
	

}
