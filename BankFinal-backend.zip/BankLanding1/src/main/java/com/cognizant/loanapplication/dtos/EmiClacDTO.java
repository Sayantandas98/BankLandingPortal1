package com.cognizant.loanapplication.dtos;

import lombok.Data;

@Data
public class EmiClacDTO {
	private double emi;
	private double totalAmountPayable;
}
