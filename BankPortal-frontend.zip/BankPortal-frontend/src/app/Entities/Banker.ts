export class Banker{
    userName!: number;
    password!: string;
    role!: string;
    isAccountLocked!:boolean;
}