export class CreditRisk{
    crId!:string;
    creditScore!:number;
    emi!:number;
    basicCheck!:string

}