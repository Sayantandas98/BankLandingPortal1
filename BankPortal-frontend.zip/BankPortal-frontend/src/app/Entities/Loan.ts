export class Loan{
    principleAmount!:DoubleRange;
    monthlyinterestRate!:DoubleRange;
    loanTenureMonths!:number;
    dueDate!:Date;
}