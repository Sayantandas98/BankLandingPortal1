export class EmiClacResponse{
    emi!:DoubleRange
    totalAmountPayable!:DoubleRange
}